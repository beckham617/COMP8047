import React from 'react';
import { Card, CardContent, CardMedia, Typography, Box, Avatar, Chip } from '@mui/material';
import { usersAPI } from '../services/api';

const getStatusColor = (status) => {
  switch (status) {
    case 'new':
      return 'success';
    case 'in_progress':
      return 'warning';
    case 'completed':
      return 'info';
    case 'cancelled':
      return 'error';
    default:
      return 'default';
  }
};

const getUserPlanStatusColor = (status) => {
  switch (status) {
    case 'owned':
      return 'primary';
    case 'applied':
      return 'warning';
    case 'applied_accepted':
      return 'success';
    case 'applied_refused':
      return 'error';
    case 'applied_cancelled':
      return 'error';
    case 'invited':
      return 'info';
    case 'invited_accepted':
      return 'success';
    case 'invited_refused':
      return 'error';
    default:
      return 'default';
  }
};

const PlanCard = ({ plan, onClick }) => {
  const planStatusRaw = (plan.planStatus || plan.status || 'new').toString().toLowerCase();
  const planStatusLabel = (plan.planStatus || plan.status || 'NEW').toString().replace(/_/g, ' ');
  const ownerAvatar = plan.ownerAvatar ? usersAPI.getProfilePicture(plan.ownerAvatar) : (plan.ownerAvatar || 'https://via.placeholder.com/150');
  const coverImage = (Array.isArray(plan.images) && plan.images.length > 0)
    ? usersAPI.getProfilePicture(plan.images[0])
    : (plan.coverImage || 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80');

  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        cursor: 'pointer',
        transition: 'transform 0.2s, box-shadow 0.2s',
        '&:hover': {
          transform: 'translateY(-4px)',
          boxShadow: 4,
        }
      }}
      onClick={onClick}
    >
      <CardMedia
        component="img"
        height="200"
        image={coverImage}
        alt={plan.title}
        sx={{ width: '100%', height: 200, objectFit: 'cover', objectPosition: 'center' }}
      />
      <CardContent sx={{ flexGrow: 1, position: 'relative' }}>
        <Typography variant="h6" component="h2" gutterBottom>
          {plan.title}
        </Typography>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          {plan.description}
        </Typography>

        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Avatar src={ownerAvatar} sx={{ width: 32, height: 32, mr: 1 }} />
          <Typography variant="body2" color="text.secondary">
            {plan.ownerName}
          </Typography>
        </Box>

        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <Chip
              label={planStatusLabel}
              color={getStatusColor(planStatusRaw)}
              size="small"
            />
            {plan.userPlanStatus && (
              <Chip
                label={plan.userPlanStatus.toString().replace(/_/g, ' ')}
                color={getUserPlanStatusColor(plan.userPlanStatus.toString().toLowerCase())}
                size="small"
              />
            )}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

export default PlanCard;


