package com.comp8047.majorproject.travelplanassistant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelplanassistantApplicationTests {

	@Test
	void contextLoads() {
	}

}
